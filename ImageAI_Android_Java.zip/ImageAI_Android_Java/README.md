# ImageAI Android (Java) — starter project

## Open
1. Unzip the project.
2. Open the `ImageAI_Android_Java` folder in Android Studio.
3. Allow Gradle sync, then run on an Android device/emulator with internet access.

## Included
- Dark ChatGPT-inspired interface, responsive scroll layout
- Prompt input, style chip, generate button, result preview
- First attempt at the legacy Pollinations anonymous image endpoint
- Java native Android app, min SDK 23

## Important limitations
- This is a starter prototype, not a finished production app.
- Pollinations' anonymous/legacy endpoint may change, rate-limit, or require authentication.
- AI Horde is mentioned in the UI but its API workflow is not yet integrated. A reliable fallback requires testing current endpoints and request formats.
- Save, gallery/history, image ratio/model selection, and settings are UI placeholders and need implementation.
- The layout is inspired by the reference, not a pixel-perfect copy; the generated reference screenshot is a desktop concept while this app adapts to phone screens.
