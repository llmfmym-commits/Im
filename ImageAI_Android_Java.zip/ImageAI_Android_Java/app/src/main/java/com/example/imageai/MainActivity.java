package com.example.imageai;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.content.*;
import android.net.Uri;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import java.io.*;
import java.net.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(13,18,26), panel = Color.rgb(24,31,42), card = Color.rgb(31,40,53);
    private final int white = Color.rgb(242,245,249), muted = Color.rgb(166,177,193), teal = Color.rgb(20,137,119);
    private EditText prompt;
    private ImageView resultImage;
    private TextView status;
    private LinearLayout root, content;
    private ProgressBar progress;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        buildUI();
    }
    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private void pad(View v, int a, int b, int c, int d) { v.setPadding(a,b,c,d); }
    private TextView button(String label, int color, Runnable action) {
        TextView t = text(label, 14, white, true); t.setGravity(Gravity.CENTER); t.setPadding(16,13,16,13); t.setBackground(shape(color, 24));
        t.setOnClickListener(v -> action.run()); return t;
    }
    private void buildUI() {
        root = column(); root.setBackgroundColor(bg);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        content = column(); pad(content,18,12,18,22);
        LinearLayout header = row();
        TextView logo = text("✳", 28, white, true); logo.setGravity(Gravity.CENTER); logo.setBackground(shape(teal, 60)); logo.setWidth(48); logo.setHeight(48);
        LinearLayout titleBox = column(); pad(titleBox,12,0,0,0);
        titleBox.addView(text("ImageAI",22,white,true)); titleBox.addView(text("Create · Imagine · Realize",12,muted,false));
        header.addView(logo); header.addView(titleBox, new LinearLayout.LayoutParams(0,-2,1));
        header.addView(text("☼   ☾   ⋮",20,muted,false)); content.addView(header);
        TextView heading = text("Image Generator",25,white,true); pad(heading,0,25,0,2); content.addView(heading);
        content.addView(text("Turn your ideas into stunning images",14,muted,false));
        LinearLayout nav = row(); nav.setPadding(0,18,0,18);
        nav.addView(button("＋ New Image",teal,()->prompt.requestFocus()));
        nav.addView(space(8)); nav.addView(button("▦ Gallery",card,()->show("Your generated images will appear here during this session.")));
        content.addView(nav);
        TextView promptLabel = text("Describe your image",16,white,true); pad(promptLabel,0,8,0,8); content.addView(promptLabel);
        prompt = new EditText(this); prompt.setTextColor(white); prompt.setHintTextColor(muted); prompt.setTextSize(15);
        prompt.setHint("A cinematic mountain lake at sunset...");
        prompt.setGravity(Gravity.TOP|Gravity.START); prompt.setMinLines(3); prompt.setPadding(16,14,16,14); prompt.setBackground(shape(card,20));
        content.addView(prompt, new LinearLayout.LayoutParams(-1,-2));
        LinearLayout options = row(); options.setPadding(0,10,0,16);
        options.addView(button("Realistic",card,()->prompt.append(", photorealistic style")));
        options.addView(space(8)); options.addView(button("1:1 Square",card,()->{}));
        content.addView(options);
        TextView generate = button("✦   Generate image",teal,()->generate()); content.addView(generate);
        status = text("Ready when you are.",13,muted,false); pad(status,2,12,0,8); content.addView(status);
        progress = new ProgressBar(this); progress.setVisibility(View.GONE); content.addView(progress);
        resultImage = new ImageView(this); resultImage.setAdjustViewBounds(true); resultImage.setScaleType(ImageView.ScaleType.CENTER_CROP);
        resultImage.setBackground(shape(card,20)); resultImage.setVisibility(View.GONE);
        LinearLayout.LayoutParams imgParams = new LinearLayout.LayoutParams(-1, 760); imgParams.topMargin=8; content.addView(resultImage,imgParams);
        LinearLayout actions = row(); actions.setPadding(0,10,0,0);
        actions.addView(button("↓ Save",card,()->saveImage())); actions.addView(space(8));
        actions.addView(button("↻ Regenerate",card,()->generate())); content.addView(actions);
        TextView provider = text("Powered by Pollinations.AI + AI Horde\nNo API key is configured in this starter project.",13,muted,false);
        provider.setBackground(shape(panel,18)); pad(provider,16,16,16,16); pad(provider,0,22,0,0); content.addView(provider);
        scroll.addView(content); root.addView(scroll); setContentView(root);
    }
    private View space(int w) { View v = new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(w,1)); return v; }
    private void show(String s) { new AlertDialog.Builder(this).setTitle("ImageAI").setMessage(s).setPositiveButton("OK",null).show(); }
    private void generate() {
        String p = prompt.getText().toString().trim();
        if (p.isEmpty()) { prompt.setError("Describe the image first"); return; }
        ((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(prompt.getWindowToken(),0);
        status.setText("Generating image…"); progress.setVisibility(View.VISIBLE);
        // Legacy Pollinations URL is tried first. Endpoint availability and anonymous access can change.
        executor.execute(() -> {
            Bitmap bitmap = null; String err = null;
            try {
                String encoded = URLEncoder.encode(p, "UTF-8").replace("+","%20");
                URL url = new URL("https://image.pollinations.ai/prompt/" + encoded + "?width=768&height=768&nologo=true");
                HttpURLConnection c = (HttpURLConnection)url.openConnection();
                c.setConnectTimeout(20000); c.setReadTimeout(90000); c.setRequestMethod("GET");
                c.setRequestProperty("User-Agent","ImageAI-Android/1.0");
                int code = c.getResponseCode();
                if (code >= 200 && code < 300) bitmap = BitmapFactory.decodeStream(c.getInputStream());
                else err = "Pollinations returned HTTP " + code;
                c.disconnect();
            } catch(Exception e) { err = e.getMessage(); }
            final Bitmap result = bitmap; final String error = err;
            runOnUiThread(() -> {
                progress.setVisibility(View.GONE);
                if (result != null) {
                    resultImage.setImageBitmap(result); resultImage.setVisibility(View.VISIBLE);
                    status.setText("Image generated successfully.");
                } else {
                    status.setText("Could not generate image.");
                    show("The anonymous Pollinations endpoint may be unavailable or may now require a key.\n\nDetails: " + error +
                         "\n\nAI Horde is listed as a future fallback; its request flow still needs to be integrated and tested.");
                }
            });
        });
    }
    private void saveImage() {
        if (resultImage.getDrawable()==null) { show("Generate an image first."); return; }
        show("Image is visible in the app. For a production build, add Android MediaStore saving and permission handling.");
    }
    @Override protected void onDestroy() { super.onDestroy(); executor.shutdownNow(); }
}
